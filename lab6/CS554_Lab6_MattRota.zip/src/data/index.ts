const tasks = require("./tasks");

module.exports = {
	tasks: tasks
};